import 'dart:convert';

import 'package:csimageloader/Services/remote_services.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../model/pixar_image/hit.dart';
import '../model/pixar_image/pixar_image.dart';

class HomeScreenController extends GetxController {
  final searchController = TextEditingController();
  final scrollController = ScrollController();
  int page = 1;

  RxList<Hit> imageList = List<Hit>.empty(growable: true).obs;
  RxList<Hit> newImages = List<Hit>.empty(growable: true).obs;
  getMore(page) async {
    try {
      page = page + 1;
      var result = await RemoteImage().get(searchController.text, page);
      final jsonRes = json.decode(result.body) as Map<String, dynamic>;
      final data = PixarImage.fromJson(jsonRes);
      newImages.value = data.hits!;
      imageList.addAll(newImages);
    } catch (e) {
      print(e);
    }
  }

  void getImages(searchItem) async {
    try {
      var result = await RemoteImage().get(searchItem, page);
      final jsonRes = json.decode(result.body) as Map<String, dynamic>;
      final data = PixarImage.fromJson(jsonRes);
      imageList.value = data.hits!;
    } catch (err) {
      print(err);
    }
  }

  @override
  void onClose() {
    scrollController.dispose();
    super.onClose();
  }
}
