import 'package:http/http.dart' as http;

class RemoteImage {
  var client = http.Client();
  Future<dynamic> get(String searchItem, int page) async {
    try {
      var response = await client.get(
        Uri.parse(
            'https://pixabay.com/api/?key=29770507-5a6019a378cdf08ab1b60f5a3&q=$searchItem&image_type=photo&pretty=true&page=$page'),
      );
      return response;
    } catch (e) {
      print(e);
    }
    // print(response.body);
  }
}
