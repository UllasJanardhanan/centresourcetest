import 'package:cached_network_image/cached_network_image.dart';
import 'package:csimageloader/Services/remote_services.dart';
import 'package:csimageloader/controller/home_screen_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../model/pixar_image/hit.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    HomeScreenController controller = Get.put(HomeScreenController());
    return Scaffold(
      body: SafeArea(
          child: Column(children: [
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(color: Colors.grey.withOpacity(0.6), blurRadius: 10),
            ],
          ),
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: const BorderRadius.all(Radius.circular(24)),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                          color: Colors.grey.withOpacity(0.6), blurRadius: 10),
                    ],
                  ),
                  child: TextField(
                    controller: controller.searchController,
                    autofocus: false,
                    // onSubmitted: (value) {},
                    // onChanged: (value) {},
                    decoration: InputDecoration(
                        contentPadding: const EdgeInsets.symmetric(
                            vertical: 16, horizontal: 14),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(24.0),
                          borderSide: BorderSide.none,
                        ),
                        fillColor: Colors.white,
                        filled: true,
                        prefixIcon: Icon(Icons.search,
                            color: Colors.black.withOpacity(0.5)),
                        hintText: 'Search....'),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              GestureDetector(
                onTap: () {
                  controller.getImages(controller.searchController.text);
                },
                child: Container(
                    height: 46,
                    width: 46,
                    decoration: BoxDecoration(
                      borderRadius: const BorderRadius.all(Radius.circular(24)),
                      color: Colors.white,
                      boxShadow: <BoxShadow>[
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.6),
                          blurRadius: 8,
                        ),
                      ],
                    ),
                    child: Icon(
                      Icons.search,
                      color: Colors.black.withOpacity(0.5),
                    )),
              ),
            ],
          ),
        ),
        Obx(() {
          if (controller.imageList.isNotEmpty) {
            return const ImageViewer();
          }
          return Container();
        })
      ])),
    );
  }
}

class ImageViewer extends StatelessWidget {
  const ImageViewer({Key? key, required}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    int page = 1;
    final controller = Get.find<HomeScreenController>();

    controller.scrollController.addListener(
      () {
        if (controller.scrollController.position.pixels ==
            controller.scrollController.position.maxScrollExtent) {
          controller.getMore(page);
        }
      },
    );
    print(controller.imageList.length);
    return Obx(() => Expanded(
        child: GridView.builder(
            controller: controller.scrollController,
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.all(5),
            itemCount: controller.imageList.length + 1,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisSpacing: 5, mainAxisSpacing: 5, crossAxisCount: (1)),
            itemBuilder: (BuildContext context, index) {
              if (index >= controller.imageList.length) {
                return const Padding(
                  padding: EdgeInsets.symmetric(vertical: 32),
                  child: Center(child: CircularProgressIndicator()),
                );
              } else {
                return GestureDetector(
                  onTap: () {
                    Get.to(PopUpWindow(
                      imageUrl: controller.imageList[index].webformatUrl!,
                    ));
                  },
                  child: Container(
                    margin: const EdgeInsets.all(10),
                    child: ClipRRect(
                      borderRadius: const BorderRadius.all(Radius.circular(10)),
                      child: CachedNetworkImage(
                        imageUrl: controller.imageList[index].webformatUrl!,
                        progressIndicatorBuilder:
                            (context, url, downloadprogress) => Container(
                          margin: const EdgeInsets.all(8),
                          decoration: const BoxDecoration(
                              color: Colors.grey,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(10))),
                          child: ClipRRect(
                            borderRadius:
                                const BorderRadius.all(Radius.circular(10)),
                            child: AspectRatio(
                              aspectRatio: 16 / 9,
                              child: Container(),
                            ),
                          ),
                        ),
                        fit: BoxFit.fitHeight,
                        width: double.infinity,
                      ),
                    ),
                  ),
                );
              }
            })));
  }
}

class PopUpWindow extends StatelessWidget {
  final String imageUrl;
  const PopUpWindow({super.key, required this.imageUrl});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.pop(context);
      },
      child: Container(
        height: double.infinity,
        width: double.infinity,
        color: Colors.transparent,
        child: ClipRRect(
          borderRadius: const BorderRadius.all(Radius.circular(10)),
          child: CachedNetworkImage(
            imageUrl: imageUrl,
            progressIndicatorBuilder: (context, url, downloadprogress) =>
                Container(
              margin: const EdgeInsets.all(8),
              decoration: const BoxDecoration(
                  color: Colors.grey,
                  borderRadius: BorderRadius.all(Radius.circular(10))),
              child: ClipRRect(
                borderRadius: const BorderRadius.all(Radius.circular(10)),
                child: AspectRatio(
                  aspectRatio: 16 / 9,
                  child: Container(),
                ),
              ),
            ),
            fit: BoxFit.fitHeight,
            width: double.infinity,
          ),
        ),
      ),
    );
  }
}
