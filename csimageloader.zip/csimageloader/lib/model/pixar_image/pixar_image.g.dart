// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pixar_image.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

PixarImage _$PixarImageFromJson(Map<String, dynamic> json) => PixarImage(
      total: json['total'] as int?,
      totalHits: json['totalHits'] as int?,
      hits: (json['hits'] as List<dynamic>?)
          ?.map((e) => Hit.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$PixarImageToJson(PixarImage instance) =>
    <String, dynamic>{
      'total': instance.total,
      'totalHits': instance.totalHits,
      'hits': instance.hits,
    };
