// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'hit.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Hit _$HitFromJson(Map<String, dynamic> json) => Hit(
      previewUrl: json['previewURL'] as String?,
      webformatUrl: json['webformatURL'] as String?,
      largeImageUrl: json['largeImageURL'] as String?,
    );

Map<String, dynamic> _$HitToJson(Hit instance) => <String, dynamic>{
      'previewURL': instance.previewUrl,
      'webformatURL': instance.webformatUrl,
      'largeImageURL': instance.largeImageUrl,
    };
