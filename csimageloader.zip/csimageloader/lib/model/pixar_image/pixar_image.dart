import 'package:json_annotation/json_annotation.dart';

import 'hit.dart';

part 'pixar_image.g.dart';

@JsonSerializable()
class PixarImage {
  @JsonKey(name: 'total')
  int? total;
  @JsonKey(name: 'totalHits')
  int? totalHits;
  @JsonKey(name: 'hits')
  List<Hit>? hits;

  PixarImage({this.total, this.totalHits, this.hits});

  factory PixarImage.fromJson(Map<String, dynamic> json) {
    return _$PixarImageFromJson(json);
  }

  Map<String, dynamic> toJson() => _$PixarImageToJson(this);
}
