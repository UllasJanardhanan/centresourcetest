import 'package:json_annotation/json_annotation.dart';

part 'hit.g.dart';

@JsonSerializable()
class Hit {
  @JsonKey(name: 'previewURL')
  String? previewUrl;
  @JsonKey(name: 'webformatURL')
  String? webformatUrl;
  @JsonKey(name: 'largeImageURL')
  String? largeImageUrl;

  Hit({
    this.previewUrl,
    this.webformatUrl,
    this.largeImageUrl,
  });

  factory Hit.fromJson(Map<String, dynamic> json) => _$HitFromJson(json);

  Map<String, dynamic> toJson() => _$HitToJson(this);
}
