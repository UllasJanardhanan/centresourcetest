package com.example.csimageloader

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
